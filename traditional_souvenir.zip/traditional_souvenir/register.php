<?php

include 'connect.php';

if(isset($_POST['regist'])) {
    $user_name = $_POST['user_name'];
    $user_email = $_POST['user_email'];
    $user_password = $_POST['user_password'];
    $user_access = 'user';

    $query = "INSERT INTO users (`user_name`, `user_email`, `user_password`, `user_access`) VALUES ('$user_name', '$user_email', '$user_password', '$user_access')";
    $query_run = mysqli_query($connect, $query);


    if($query_run) {
        echo '<script> alert("Data Saved"); </script>';
        header('Location: login-form.php');
    }
    else {
        echo '<script> alert("Data not saved"); </script>';
    }
}


?>