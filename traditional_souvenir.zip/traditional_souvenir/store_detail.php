<?php
session_start();
include 'connect.php';

$store_id = $_GET['store_id'];
$queryStore = mysqli_query($connect, "SELECT * FROM store WHERE store_id = '$store_id'");
$dataStore = mysqli_fetch_array($queryStore);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
    <link rel="stylesheet" href="css/style-store.css">
    <link rel = "stylesheet" href = "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.2.0/dist/leaflet.css" />
    <link rel="stylesheet" href="js/leaflet-routing-machine/dist/leaflet-routing-machine.css" />
    <script src = "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet@1.2.0/dist/leaflet.js"></script>
    <script src="js/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>

    </head>

<style>
#map {
    width: 100%;
    height: 500px;
    zoom: 90%;
}

td {
    height: 80px;
}

.card {
    transition: all 300ms;
}

.card:hover {
    transform: scale(1.05);
    background-color: #F0F0F0;
}
</style>

<body>
    <?php require "navbar.php"; ?>

    <!-- body -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <h2><strong>Store Details</strong></h2>
                <hr>
                <div class="col-lg-6 mb-4">
                <img src="img/store/<?php echo $dataStore['store_image']; ?>" style="zoom:50%; display: block; margin-left: auto; margin-right: auto; width: 50%;margin-bottom:5px;">
                    <table>
                        <tr>
                            <td width="180px">Store Name</td>
                            <td><?php echo $dataStore['store_name']; ?></td>
                        </tr>
                        <tr>
                            <td>Address</td>
                            <td><?php echo $dataStore['store_address']; ?></td>
                        </tr>
                        <tr>
                            <td>Phone Number</td>
                            <td><?php echo $dataStore['store_phone_number']; ?></td>
                        </tr>
                    </table>
                </div>

                <div class="col-lg-6 ">
                    <div id="map"></div>
                    <script>
                    // Creating map options
                    var mapOptions = {
                        center: [<?php echo $dataStore['store_lat']; ?>, <?php echo $dataStore['store_lng']; ?>],
                        zoom: 17
                    }
                    
                    // Creating a map object
                    var map = new L.map('map', mapOptions);
                    
                    // Creating a Layer object
                    var layer = new L.TileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
                    
                    // Adding layer to the map
                    map.addLayer(layer);

                    // marker
                    var myIcon = L.icon({
                        iconUrl: 'img/icon/location.png',
                        iconSize: [26,45],
                    });
                    // L.marker([-6.1969564, 106.8200429]).addTo(map);

                    <?php
                    include 'connect.php';
                    $getData = mysqli_query($connect, "SELECT * FROM store WHERE store_id = '$store_id'");
                    if (mysqli_num_rows($getData)) {
                        // $ambildata = mysqli_query($koneksi, "select * from peminjaman");
                        while ($showData = mysqli_fetch_array($getData)) {
                    ?>
                    L.marker([<?php echo $showData['store_lat']; ?>, <?php echo $showData['store_lng']; ?>]).addTo(map).bindPopup("<h6><b><?php echo $showData['store_name']; ?></b></h6>").openPopup();
                    <?php
                        }
                    } else { }
                    ?>

                    getLocation();
                    // setInterval(() => {
                    //     getLocation();
                    // }, 3000);

                    function getLocation() {
                        if(navigator.geolocation){
                            navigator.geolocation.getCurrentPosition(showPosition);
                        } else {
                            x.innerHTML = "Geolocation is not supported by this browser.";
                        }

                        function showPosition(position) {
                            console.log('Route sekarang' , position.coords.latitude, position.coords.longitude)
                            let latLng = [position.coords.latitude, position.coords.longitude];
                                control.spliceWaypoints(0,1, latLng);
                                if(centerMap==false){
                                    map.panTo(latLng);
                                    centerMap = true;
                                }
                        }
                    }

                    //route direction
                    var control = L.Routing.control({
                    waypoints: [
                        L.latLng(-6.1969564, 106.8200429)
                    ]
                    });

                    control.addTo(map);

                    function goHere(lat, lng){
                        var latLng = L.latLng(lat, lng);
                        control.spliceWaypoints(control.getWaypoints().length - 1, 1, latLng);
                    }
                    </script>
                    <div class="text-center">
                        <button onclick="return goHere(<?php echo $dataStore['store_lat']; ?>, <?php echo $dataStore['store_lng']; ?>)" class="btn btn-primary mt-3"><i class="fa-light fa-map-pin"></i> Direction</button>
                    </div>
                </div>
                
            </div>
        </div>
        
    </div>
    
    <!-- Related Product -->
    <div class="container-fluid py-3 color2">
        <div class="container">
            <h2><strong>Store Product</strong></h2>
            <hr>
            <div class="row">
            <?php
                $queryProduct = mysqli_query($connect, "SELECT * FROM product WHERE store_id = '$dataStore[store_id]'") or die (mysqli_error($connect));
                while($dataProduct = mysqli_fetch_array($queryProduct)) {
                ?>
                <div class="col-md-6 col-lg-3 mb-3">
                    <a href="product_detail.php?product_id=<?php echo $dataProduct['product_id']; ?>" style="text-decoration: none; color:black;">
                        <div class="card h-100">
                            <img class="card-img-top" src="img/product/<?php echo $dataProduct['product_image']; ?>" style="width: 100%; height:250px; object-fit: cover; object-position: center;display: block;margin-left: auto;margin-right: auto; cursor:pointer;">
                            <div class="card-body">
                                <p class="card-text" style="display: none;"><?php echo $dataProduct['product_id']; ?></p>
                                <p class="card-text" style="display: none;"><?php echo $dataProduct['product_image']; ?></p>
                                <h6 class="card-title" style="font-weight:bold;"><?php echo $dataProduct['product_name']; ?></h5>
                                <p class="card-text" style="color: #F45050; font-weight:bold; font-size:16px;">Rp <?php echo number_format($dataProduct['product_price']); ?></p>
                                <input type="hidden" name="product_name" value="<?=$dataProduct['product_name']?>">
                                <input type="hidden" name="product_price" value="<?=$dataProduct['product_price']?>">
                                <a href="product_detail.php?product_id=<?php echo $dataProduct['product_id']; ?>" class="btn btn-primary" ><i class="fa-solid fa-magnifying-glass"></i> Lihat Detail</a>
                            </div>
                        </div>
                    </a>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>