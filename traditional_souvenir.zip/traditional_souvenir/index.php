<?php
session_start();
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
    <link rel="stylesheet" href="css/style-index.css">
</head>

<style>

.color1 {
    color: #FFFFFF;
}

.color2 {
    background-color: #FEE8B0;
}

.card {
    transition: all 300ms;
}

.card:hover {
    transform: scale(1.05);
    background-color: #F0F0F0;
}

</style>

<body>
    <?php require "navbar.php"; ?>

    <!-- banner -->
    <div class="container-fluid banner d-flex align-items-center">
        <div class="container text-center">
            <h1 class="color1">Indonesian Traditional Souvenir</h1>
            <h3 class="color1">Search Souvenir?</h3>
            <div class="col-md-8 offset-md-2">
                <form action="product.php" method="GET">
                    <div class="input-group input-group-lg my-4">
                        <input type="text" class="form-control" placeholder="Product name" name="search_keyword" aria-label="Product name" aria-describedby="basic-addon2">
                        <button type="submit" class="btn btn-primary">Search</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- category -->
    <div class="container-fluid py-5">
        <div class="container text-center">
            <h3>Popular Category</h3>

            <div class="row mt-5">
                <div class="col-md-4 mb-3">
                    <div class="popular_category category-pakaian d-flex justify-content-center align-items-center">
                        <h4 class="text-white"><a href="product.php?category=Pakaian" class="no-decoration">Pakaian</a></h4>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="popular_category category-makanan d-flex justify-content-center align-items-center">
                        <h4 class="text-white"><a href="product.php?category=Makanan" class="no-decoration">Makanan</a></h4>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="popular_category category-aksesoris d-flex justify-content-center align-items-center">
                    <h4 class="text-white"><a href="product.php?category=Aksesoris" class="no-decoration">Aksesoris</a></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- about us -->
    <div class="container-fluid color2 py-5">
        <div class="container text-center">
            <h3>About Us</h3>
            <p class="fs-5 mt-3">
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
        </div>
    </div>

    <!-- product -->
    <div class="container-fluid py-5">
        <div class="container text-center">
            <h3 class="">Product</h3>
            <div class="row mt-5" style="zoom: 90%;">

                <?php

                include 'connect.php';

                $query = "SELECT * FROM product LIMIT 12";
                $query_run = mysqli_query($connect, $query);
                $data = mysqli_fetch_array($query_run);

                ?>

                <?php
                    if ($query_run) {
                        foreach($query_run as $row) {
                ?>
                    <div class="col-md-3 mb-3">
                        <form action="index.php?id=<?=$row['product_id']?>" method="POST">
                            <div class="card h-100">
                                <img class="card-img-top" src="img/product/<?php echo $row['product_image']; ?>" style="width: 100%; height:250px; object-fit: cover; object-position: center;display: block;margin-left: auto;margin-right: auto; cursor:pointer;">
                                <div class="card-body">
                                    <p class="card-text" style="display: none;"><?php echo $row['product_id']; ?></p>
                                    <p class="card-text" style="display: none;"><?php echo $row['product_image']; ?></p>
                                    <h6 class="card-title" style="font-weight:bold;"><?php echo $row['product_name']; ?></h5>
                                    <p class="card-text" style="color: #F45050; font-weight:bold; font-size:16px;">Rp <?php echo number_format($row['product_price']); ?></p>
                                    <input type="hidden" name="product_name" value="<?=$row['product_name']?>">
                                    <input type="hidden" name="product_price" value="<?=$row['product_price']?>">
                                    <a href="product_detail.php?product_id=<?php echo $row['product_id']; ?>" class="btn btn-primary" ><i class="fa-solid fa-magnifying-glass"></i> Lihat Detail</a>
                                </div>
                            </div>
                        </form>
                    </div>

                <?php
                        }
                    }
                    else {
                        echo "No Data Found";
                }
                ?>
            </div>
            <a href="product.php" class="btn btn-outline-primary mt-3">See More</a>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>