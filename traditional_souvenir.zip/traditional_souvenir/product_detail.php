<?php
session_start();
include 'connect.php';

$product_id = $_GET['product_id'];
$queryProduct = mysqli_query($connect, "SELECT * FROM product WHERE product_id = '$product_id'");
$dataProduct = mysqli_fetch_array($queryProduct);

$queryRelatedProduct = mysqli_query($connect, "SELECT * FROM product WHERE category_id = '$dataProduct[category_id]' AND product_id!='$dataProduct[product_id]' LIMIT 4");

$countData = mysqli_num_rows($queryRelatedProduct);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
    <link rel="stylesheet" href="css/style-pdetail.css">
</head>

<style>
.color2 {
    background-color: #FEE8B0;
}

img {
    transition: all 300ms;
}

img:hover {
    transform: scale(1.05);
    background-color: #F0F0F0;
}
</style>

<body>
    <?php require "navbar.php"; ?>
    
    <!-- product detail -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 mb-4">
                    <img src="img/product/<?php echo $dataProduct['product_image']; ?>" class="w-100" alt="">
                </div>
                <div class="col-lg-6 offset-lg-1">
                    <h1><?php echo $dataProduct['product_name']; ?></h1>
                    <p><?php echo $dataProduct['product_desc']; ?></p>
                    <p class="fs-4" style="color: #F45050;">Rp <?php echo number_format($dataProduct['product_price']); ?></p>
                    <button type="button" class="btn btn-primary mb-4" data-toggle="tooltip" title="pesan" data-bs-toggle="modal" data-bs-target="#pesan"
                    data-product_id="<?php echo $dataProduct['product_id']; ?>"
                    data-product_name="<?php echo $dataProduct['product_name']; ?>"
                    data-product_stock="<?php echo $dataProduct['product_stock']; ?>"
                    data-product_price="<?php echo $dataProduct['product_price']; ?>"
                    data-product_image="<?php echo $dataProduct['product_image']; ?>"><i class="fa-solid fa-cart-plus cart"></i> Add to Cart</button>
                    <p class="fs-6">Product Availability : <strong><?php echo $dataProduct['product_stock']; ?></strong></p>
                </div>
            </div>
        </div>
    </div>


    <!-- Add To Cart Modal -->
    <div class="modal fade" id="pesan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Add to cart </h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="add_to_cart.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div hidden>
                            <input type="text" name="user_id" id="user_id" value="<?php echo $_SESSION['user_id'];?>">
                            <input type="text" name="product_id" id="product_id" value="<?php echo $dataProduct['product_id'];?>" >
                            <input type="text" name="product_name" id="product_name" value="<?php echo $dataProduct['product_name'];?>">
                            <input type="text" name="product_image" id="product_image" value="<?php echo $dataProduct['product_image'];?>">
                            <input type="text" name="product_price" id="product_price" value="<?php echo $dataProduct['product_price'];?>">
                        </div>
                        <input type="text" name="product_name" id="product_name" value="<?php echo $dataProduct['product_name'];?>" class="form-control" disabled><br>
                        <div class="form-group mb-4">
                            <label class="mb-2">Quantity</label>
                            <input type="number" name="product_quantity" id="product_quantity" class="form-control" placeholder="Input Quantity">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="order" class="btn btn-primary">Save changes</button>
                    </div>
                </form> 
            </div>
        </div>
    </div>

    <!-- Related Product -->
    <div class="container-fluid py-5 color2">
        <div class="container">
            <h2 class="text-center mb-5">Related Product</h2>

            <?php if($countData<1){ ?>
                <h5 class="text-center my-5">No Related Product</h5>
            <?php } ?>
            <div class="row">

                <?php  while($row = mysqli_fetch_array($queryRelatedProduct)){ ?>
                <div class="col-md-6 col-lg-3 mb-3">
                    <a href="product_detail.php?product_id=<?php echo $row['product_id']; ?>">
                    <img src="img/product/<?php echo $row['product_image']; ?>" class="img-fluid img-thumbnail h-100" style=" object-fit: cover; object-position: center;" alt="">
                    </a>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>



<script>
    // java script for get value from item
    $('#pesan').on('show.bs.modal', function (event) {
        
        // event.relatedtarget menampilkan elemen mana yang digunakan saat diklik.
        var button              = $(event.relatedTarget)

            // data-data yang disimpan pada tombol edit dimasukkan ke dalam variabelnya masing-masing 
        var product_id = button.data('product_id')
        var product_name = button.data('product_name')
        var product_stock = button.data('product_stock')
        var product_price = button.data('product_price')
        var product_image = button.data('product_image')
        var modal = $(this)

            //variabel di atas dimasukkan ke dalam element yang sesuai dengan idnya masing-masing
        modal.find('#product_id').val(product_id)
        modal.find('#product_name').val(product_name)
        modal.find('#product_stock').val(product_stock)
        modal.find('#product_price').val(product_price)
        modal.find('#product_image').val(product_image)
    })
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</body>
</html>