<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="css/style-login.css">
</head>
<body>
    
    <div class="box-outside">
        <div class="container">
            
            <div class="forms">
                <div class="form login">
                    <span class="title">Login</span>
                    <form action="login.php" method="post">
                        <div class="input-field">
                            <input type="text" name="user_email" placeholder="Enter your email" required>
                            <i class="fa-regular fa-envelope icon"></i>
                        </div>
                        <div class="input-field">
                            <input type="password" class="password" name="user_password" placeholder="Enter your password" required>
                            <i class="fa-regular fa-lock icon"></i>
                            <i class="fa-regular fa-eye-slash show"></i>
                        </div>
                        <div class="input-field button">
                            <input type="submit" name="login" value="Login">
                        </div>
                        
                    </form>
                    <div class="login-signup">
                        <span class="text">Don't have an account?
                            <a href="#" class="text signup-text">Sign Up</a>
                        </span>
                    </div>
                </div>


                <!-- registration form -->
                <div class="form signup">
                    <span class="title">Registration</span>

                    <form action="register.php" method="post">
                        <div class="input-field">
                            <input type="text" name="user_name" placeholder="Enter your name" required>
                            <i class="fa-regular fa-user icon"></i>
                        </div>
                        <div class="input-field">
                            <input type="text" name="user_email" placeholder="Enter your email" required>
                            <i class="fa-regular fa-envelope icon"></i>
                        </div>
                        <div class="input-field">
                            <input type="password" class="password" name="user_password" placeholder="Create your password" required>
                            <i class="fa-regular fa-lock icon"></i>
                        </div>
                        <div class="input-field">
                            <input type="password" class="password" name="user_password" placeholder="Confirm your password" required>
                            <i class="fa-regular fa-lock icon"></i>
                            <i class="fa-regular fa-eye-slash show"></i>
                        </div>
                        <div class="input-field button">
                            <input type="submit" name="regist" value="Register">
                        </div>
                    </form>
                    <div class="login-signup">
                        <span class="text">Already have an account?
                            <a href="#" class="text login-link">Login now</a>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<script>
    const container = document.querySelector(".container"),
              passwordshow = document.querySelectorAll(".show"),
              passwordfield = document.querySelectorAll(".password"),
              signUp = document.querySelector(".signup-text"),
              login = document.querySelector(".login-link");

              passwordshow.forEach(eyeIcon =>{
                eyeIcon.addEventListener("click", ()=>{
                    passwordfield.forEach(passwordfield =>{
                        if(passwordfield.type === "password"){
                            passwordfield.type = "text";

                            passwordshow.forEach(icon =>{
                                icon.classList.replace("fa-eye-slash", "fa-eye")
                            })
                        } else {
                            passwordfield.type = "password";

                            passwordshow.forEach(icon =>{
                                icon.classList.replace("fa-eye", "fa-eye-slash")
                            })
                        }
                    })
                })
              })


              signUp.addEventListener("click", ()=>{
                container.classList.add("active");
              });
              login.addEventListener("click", ()=>{
                container.classList.remove("active");
              });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>

<?php
    unset($_SESSION["error"]);
?>