<?php
session_start();
include 'connect.php';
error_reporting(0);

$user_id = $_SESSION['user_id'];
$queryCart = mysqli_query($connect, "SELECT * FROM cart WHERE user_id = $user_id");
$data = mysqli_fetch_array($queryCart);
$total = 0;

$countData = mysqli_num_rows($queryCart);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
    <link rel="stylesheet" href="css/style-cart.css">
</head>
<body>
    
    <?php include 'navbar.php'; ?>

    <!-- banner -->
    <div class="container-fluid banner d-flex align-items-center">
        <div class="container">
            <h1 class="text-white text-center">#cart</h1>
        </div>
    </div>

    <section id="cart" >
    <table width="100%" >
            <thead>
                <tr>
                    <td>Remove</td>
                    <td>Product</td>
                    <td>Price</td>
                    <td>Quantity</td>
                    <td>Subtotal</td>
                </tr>
            </thead>
            <tbody>
            <?php
                            if ($queryCart) {
                                foreach($queryCart as $row) {
                        ?>
                <?php
                                    $transaction_status=$row['transaction_status'];
                                    if($transaction_status=='Shipping'){
                                    } else{
                                        ?>
                                    
                                    <tr>
                                        <td style="display: none;"><?php echo $row['product_id']?></td>
                                        <td style="display: none;"><?php echo $row['cart_id']?></td>
                                        <td><a href='delete_cart.php?cart_id=<?php echo $row["cart_id"];?>' ><i class="fa-solid fa-xmark" style="cursor: pointer; color: red;"></i></a></td>
                                        <td><?php echo $row['product_name']?></td>
                                        <td>Rp <?php echo number_format($row['product_price'])?>
                                    </td>
                                        <td><?php echo $row['product_quantity']?></td>
                                        <td>Rp <?php echo number_format($row['product_price'] * $row['product_quantity'],2)?></td>
                                    </tr>
                                            
                                    <?php
                                            $total = $total + $row['product_price'] * $row['product_quantity'];
                                                ?>
                               <?php 
                                    } 
                                }
                            }
                            else {
                                echo "No Data Found";
                            }
                            ?>
                </tbody>
        </table>
    </section>

    <section id="cart-add" style="padding: 40px 80px;">

    <?php if($countData<1){ ?>
        <div class="container">
            <h5 class="text-center mb-3">Cart is empty</h5>
        </div>
    <?php } ?>

        <div id="subtotal" class="my-4 border border-secondary p-3">
            <div class="container-fluid align-items-center">
                <div class="container">
                    <h3>Cart Totals</h3>
                    <table class="w-100" >
                        <tr>
                            <td>Cart Subtotal</td>
                            <td>Rp <?php echo number_format($total, 2) ?></td>
                        </tr>
                        <tr>
                            <td>Shipping</td>
                            <td>Free</td>
                        </tr>
                        <tr>
                            <td><strong>Total</strong></td>
                            <td><strong>Rp <?php echo number_format($total, 2) ?></strong></td>
                        </tr>
                    </table>
                    
                </div>
            </div>
            
        </div>
        <?php
                        $transaction_status=$data['transaction_status'];
                        if($transaction_status=='Request'){
                    ?>
                    <div class="container-fluid align-items-center">
                        <div class="container text-center">
                            <a><button type="button" class="normal btn btn-primary" id="btn-approve" disabled>Waiting for Approvement</button></a>
                        </div>
                    </div>
                                <?php
                            }else if ($transaction_status=='Approved'){
                                ?>
                    <a href="ChoosePayment/index.php"><button type="button" class="normal btn btn-primary " id="btn-approve">Checkout</button></a>
                    <?php
                            } else { ?>
                        <div class="container-fluid align-items-center">
                            <div class="container text-center">
                                <a href="product.php"><button type="button" class="normal btn btn-primary " id="btn-approve">See All Product</button></a>
                            </div>
                        </div>
                            <?php }
                    ?>
            <!-- <button class="normal">Proceed to Checkout</button> -->
            
            
    </section>
    <script>
        function showDiv() {
            document.getElementById('btn-approve').style.display = "block";
            }

    </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</html>