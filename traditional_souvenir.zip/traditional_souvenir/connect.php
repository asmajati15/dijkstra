<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "traditional_souvenir";

$connect = mysqli_connect($host, $user, $password, $database);

?>