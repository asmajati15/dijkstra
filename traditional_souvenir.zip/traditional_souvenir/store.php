<?php
session_start();
include 'connect.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
    <link rel="stylesheet" href="css/style-store.css">
    <link rel = "stylesheet" href = "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.2.0/dist/leaflet.css" />
    <link rel="stylesheet" href="js/leaflet-routing-machine/dist/leaflet-routing-machine.css" />
    <script src = "http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet@1.2.0/dist/leaflet.js"></script>
    <script src="js/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>

    </head>

<style>
    #map {
    height: 400px;
}
</style>

<body>
    <?php require "navbar.php"; ?>

    <!-- banner -->
    <div class="container-fluid banner d-flex align-items-center">
        <div class="container">
            <h1 class="text-white text-center">#store</h1>
        </div>
    </div>

    <!-- body -->
    <div class="container py-5">
        <h3>Store Location</h3>
        <div id="map"></div>
        <script>
         // Creating map options
         var mapOptions = {
            center: [-6.19592, 106.8455336],
            zoom: 12
         }
         
         // Creating a map object
         var map = new L.map('map', mapOptions);
         
         // Creating a Layer object
         var layer = new L.TileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
         
         let centerMap = false;
         // Adding layer to the map
         map.addLayer(layer);

         
        // marker
        var myIcon = L.icon({
            iconUrl: 'img/icon/location.png',
            iconSize: [26,45],
        });


         <?php
        include 'connect.php';
        $getData = mysqli_query($connect, "SELECT * FROM store");
        if (mysqli_num_rows($getData)) {
            // $ambildata = mysqli_query($koneksi, "select * from peminjaman");
            while ($showData = mysqli_fetch_array($getData)) {
        ?>
        L.marker([<?php echo $showData['store_lat']; ?>, <?php echo $showData['store_lng']; ?>],{icon: myIcon}).addTo(map).bindPopup("<img src='img/store/<?php echo $showData['store_image']; ?>' style='width:100%; margin-bottom:5px;'><br>"+
        "Store Name: <strong><?php echo $showData['store_name']; ?> </strong> <br>"+
         "Category: <?php echo $showData['store_category']; ?><br>"+
         "<a href='store_detail.php?store_id=<?php echo $showData['store_id']; ?>' style='text-decoration:none;'><i class='fa-solid fa-magnifying-glass'></i> Lihat Detail </a>"+
         "<button style='background:none;border:none; color:green;' onclick='return goHere(<?php echo $showData['store_lat']; ?>, <?php echo $showData['store_lng']; ?>)'><i class='fa-regular fa-diamond-turn-right'></i> Direction</button>");
        <?php
            }
        } else { }
    ?>



        getLocation();
        // setInterval(() => {
        //     getLocation();
        // }, 3000);

        function getLocation() {
            if(navigator.geolocation){
                navigator.geolocation.getCurrentPosition(showPosition);
            } else {
                x.innerHTML = "Geolocation is not supported by this browser.";
            }

            function showPosition(position) {
                console.log('Route sekarang' , position.coords.latitude, position.coords.longitude)
                let latLng = [position.coords.latitude, position.coords.longitude];
                    control.spliceWaypoints(0,1, latLng);
                if(centerMap==false){
                    map.panTo(latLng);
                    centerMap = true;
                }
            }
        }

        //route direction
        var control = L.Routing.control({
        waypoints: [
            L.latLng(-6.1969564, 106.8200429)
        ]
        });

        control.addTo(map);

        function goHere(lat, lng){
            var latLng = L.latLng(lat, lng);
            control.spliceWaypoints(control.getWaypoints().length - 1, 1, latLng);
        }
      </script>
    </div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>