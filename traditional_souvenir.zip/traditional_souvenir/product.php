<?php
session_start();
include 'connect.php';

$queryCategory = mysqli_query($connect, "SELECT * FROM category");

//get product search keyword
if(isset($_GET['search_keyword'])){
    $queryProduct = mysqli_query($connect, "SELECT * FROM product WHERE product_name LIKE '%$_GET[search_keyword]%'");
}
//get product category
else if(isset($_GET['category'])){

    $queryGetCategoryId = mysqli_query($connect, "SELECT category_id FROM category WHERE category_name='$_GET[category]'");
    $category_id = mysqli_fetch_array($queryGetCategoryId);
    
    $queryProduct = mysqli_query($connect, "SELECT * FROM product WHERE category_id='$category_id[category_id]'");

}
// get product default
else{
    $queryProduct = mysqli_query($connect, "SELECT * FROM product");
}

$countData = mysqli_num_rows($queryProduct);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
    <link rel="stylesheet" href="css/style-product.css">
</head>

<style>
.card {
    transition: all 300ms;
}

.card:hover {
    transform: scale(1.05);
    background-color: #F0F0F0;
}
</style>

<body>
    <?php require "navbar.php"; ?>

    <!-- banner -->
    <div class="container-fluid banner d-flex align-items-center">
        <div class="container">
            <h1 class="text-white text-center">#product</h1>
        </div>
    </div>

    <!-- body -->
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-3 mb-5">
                <h3 class="mb-3">Category</h3>
                <ul class="list-group">
                    <?php while($category = mysqli_fetch_array($queryCategory)){ ?>
                    <a href="product.php?category=<?php echo $category['category_name']?>">
                    <li class="list-group-item"><?php echo $category['category_name']; ?></li>
                    </a>
                    <?php }?>
                </ul>
            </div>

            <div class="col-lg-9">
                <h3 class="text-center mb-3">Product</h3>
                <div class="row">
                    <?php if($countData<1){ ?>
                        <h5 class="text-center my-5">Product not found</h5>
                    <?php } ?>

                    <?php while($row = mysqli_fetch_array($queryProduct)){ ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img class="card-img-top" src="img/product/<?php echo $row['product_image']; ?>" style="width: 100%; height:250px; object-fit: cover; object-position: center;display: block;margin-left: auto;margin-right: auto; cursor:pointer;">
                            <div class="card-body">
                                <p class="card-text" style="display: none;"><?php echo $row['product_id']; ?></p>
                                <p class="card-text" style="display: none;"><?php echo $row['product_image']; ?></p>
                                <h6 class="card-title" style="font-weight:bold;"><?php echo $row['product_name']; ?></h5>
                                <p class="card-text" style="color: #F45050; font-weight:bold; font-size:16px;">Rp <?php echo number_format($row['product_price']); ?></p>
                                <input type="hidden" name="product_name" value="<?=$row['product_name']?>">
                                <input type="hidden" name="product_price" value="<?=$row['product_price']?>">
                                <a href="product_detail.php?product_id=<?php echo $row['product_id']; ?>" class="btn btn-primary" ><i class="fa-solid fa-magnifying-glass"></i> Lihat Detail</a>
                            </div>
                        </div>
                    </div>
                    <?php }?>
                </div>
            </div>
        </div>
    </div>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>