<?php
include '../connect.php';

$category_id = $_GET['category_id'];

$query = "DELETE FROM category WHERE category_id='$category_id'";
mysqli_query($connect, $query);

header("location:category.php");

?>