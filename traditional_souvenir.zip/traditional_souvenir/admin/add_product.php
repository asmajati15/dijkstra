<?php
include '../connect.php';

if(isset($_POST['save_product'])) {
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_desc = $_POST['product_desc'];
    $product_amount = $_POST['product_amount'];

    if($product_amount>0){
        $product_stock = 'available';
    } else {
        $product_stock = 'not available';
    }

    $category_id = $_POST['category_id'];
    $sql_category = mysqli_query($connect, "SELECT * FROM category WHERE category_id='$category_id'") or die (mysqli_error($connect));
    $dataCategory = mysqli_fetch_array($sql_category);
    $category_name = $dataCategory['category_name'];

    $product_image = $_FILES['product_image']['name'];
    $file_size = $_FILES['product_image']['size'];
    $file_temp = $_FILES['product_image']['tmp_name'];
    $folder = "../img/product/";

    $validImageExtension = ['jpg', 'jpeg', 'png'];
    $imageExtension = explode('.', $product_image);
    $imageExtension = strtolower(end($imageExtension));
        
    if(!in_array($imageExtension, $validImageExtension)){
        echo "<script> alert('Invalid Image Extension'); </script>";
    } elseif($file_size>200000000){
        echo "<script> alert('Image size is too large'); </script>";
    } else {
        $newImageName = uniqid();
        $newImageName .= '.' . $imageExtension;

        move_uploaded_file($file_temp, $folder. $newImageName);

        $query = "INSERT INTO product (`product_name`, `product_price`, `product_desc`, `product_image`, `product_amount`, `product_stock`, `category_id`, `category_name`) VALUES ('$product_name', '$product_price', '$product_desc', '$newImageName', '$product_amount', '$product_stock', '$category_id', '$category_name')";
        $query_run = mysqli_query($connect, $query);

    header('Location: product.php');
        }
}
?>