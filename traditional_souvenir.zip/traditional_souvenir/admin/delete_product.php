<?php
include '../connect.php';

$product_id = $_GET['product_id'];

$query = "DELETE FROM product WHERE product_id='$product_id'";
mysqli_query($connect, $query);

header("location:product.php");

?>