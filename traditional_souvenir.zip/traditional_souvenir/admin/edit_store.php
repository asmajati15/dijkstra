<?php
include '../connect.php';

if (isset($_POST['save_edit_store'])) {
    $store_id = $_POST['store_id'];
    $store_name = $_POST['store_name'];
    $store_address = $_POST['store_address'];
    $store_lat = $_POST['store_lat'];
    $store_lng = $_POST['store_lng'];

    $category_id = $_POST['category_id'];
    $sql_category = mysqli_query($connect, "SELECT * FROM category WHERE category_id='$category_id'") or die (mysqli_error($connect));
    $dataCategory = mysqli_fetch_array($sql_category);
    $store_category = $dataCategory['category_name'];

    $query = "UPDATE store SET store_id='$store_id', store_name='$store_name', store_address='$store_address', store_lat='$store_lat', store_lng='$store_lng', category_id='$category_id', store_category='$store_category' WHERE store_id='$store_id'";
    $query_run = mysqli_query($connect, $query);

    header("location:store.php");
}

?>