<?php
include '../connect.php';

if (isset($_POST['save_edit_category'])) {
    $category_id = $_POST['category_id'];
    $category_name = $_POST['category_name'];

    $query = "UPDATE category SET category_id='$category_id', category_name='$category_name' WHERE category_id='$category_id'";
    $query_run = mysqli_query($connect, $query);

    header("location:category.php");
}

?>