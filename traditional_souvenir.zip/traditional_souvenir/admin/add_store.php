<?php
include '../connect.php';

if(isset($_POST['save_store'])) {
    $store_name = $_POST['store_name'];
    $store_address = $_POST['store_address'];
    $store_lat = $_POST['store_lat'];
    $store_lng = $_POST['store_lng'];

    $category_id = $_POST['category_id'];
    $sql_category = mysqli_query($connect, "SELECT * FROM category WHERE category_id='$category_id'") or die (mysqli_error($connect));
    $dataCategory = mysqli_fetch_array($sql_category);
    $store_category = $dataCategory['category_name'];

    $store_image = $_FILES['store_image']['name'];
    $file_size = $_FILES['store_image']['size'];
    $file_temp = $_FILES['store_image']['tmp_name'];
    $folder = "../img/store/";

    $validImageExtension = ['jpg', 'jpeg', 'png'];
    $imageExtension = explode('.', $store_image);
    $imageExtension = strtolower(end($imageExtension));
        
    if(!in_array($imageExtension, $validImageExtension)){
        echo "<script> alert('Invalid Image Extension'); </script>";
    } elseif($file_size>200000000){
        echo "<script> alert('Image size is too large'); </script>";
    } else {
        $newImageName = uniqid();
        $newImageName .= '.' . $imageExtension;

        move_uploaded_file($file_temp, $folder. $newImageName);

        $query = "INSERT INTO store (`store_name`, `store_address`, `store_lat`, `store_lng`, `store_image`, `category_id`, `store_category`) VALUES ('$store_name', '$store_address', '$store_lat', '$store_lng', '$newImageName', '$category_id', '$store_category')";
        $query_run = mysqli_query($connect, $query);

    header('Location: store.php');
        }
}
?>