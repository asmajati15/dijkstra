<?php
include '../connect.php';

if (isset($_POST['save_category'])) {
    $category_id = $_POST['category_id'];
    $category_name = $_POST['category_name'];

    $query = "INSERT INTO category (`category_id`, `category_name`) values ('$category_id', '$category_name')";
    $query_run = mysqli_query($connect, $query);

    header("location:category.php");
}

?>