<?php
include '../connect.php';

$store_id = $_GET['store_id'];

$query = "DELETE FROM store WHERE store_id='$store_id'";
mysqli_query($connect, $query);

header("location:store.php");

?>