<?php
include '../connect.php';

if (isset($_POST['save_edit_product'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_desc = $_POST['product_desc'];
    $product_amount = $_POST['product_amount'];

    $category_id = $_POST['category_id'];
    $sql_category = mysqli_query($connect, "SELECT * FROM category WHERE category_id='$category_id'") or die (mysqli_error($connect));
    $dataCategory = mysqli_fetch_array($sql_category);
    $category_name = $dataCategory['category_name'];

    $query = "UPDATE product SET product_id='$product_id', product_name='$product_name', product_price='$product_price', product_desc='$product_desc', product_amount='$product_amount', category_id='$category_id', category_name='$category_name' WHERE product_id='$product_id'";
    $query_run = mysqli_query($connect, $query);

    header("location:product.php");
}

?>