<?php
session_start();
include '../connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.2/css/buttons.dataTables.min.css">
</head>

<style>
.no-decoration{
    text-decoration: none;
}
</style>

<body>
    <?php require "navbar.php"; ?>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item" aria-current="page">
                    <a href="index.php" class="no-decoration text-muted"><i class="fa-solid fa-house"></i> Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    Store
                </li>
            </ol>
        </nav>

        <div class="mt-4">
            <h2>Store List</h2>
            <div class="mt-4">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStore">
                    + Store
                </button>
            </div>
        </div>

        <div class="modal fade" id="addStore" tabindex="-1" aria-labelledby="addStore" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-3">Add Store</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="add_store.php" enctype="multipart/form-data" method="POST">
                            <input type="text" class="form-control" id="store_id" name="store_id" hidden>               
                            <div class="form-group mb-3">
                                <label for="store_name" class="form-label">Store Name</label>
                                <input type="text" class="form-control" id="store_name" name="store_name">               
                            </div>
                            <div class="form-group mb-3">
                                <label for="store_address" class="form-label">Store Address</label>
                                <input type="text" class="form-control" id="store_address" name="store_address">               
                            </div>
                            <div class="form-group mb-3">
                                <label for="store_image" class="form-label">Store Image</label>
                                <input type="file" class="form-control" id="store_image" name="store_image" accept=".jpg, .png, .jpeg">           
                            </div>
                            <div class="form-group mb-4">
                                <label class="mb-2">Category</label>
                                <!-- <input type="text" name="nama_barang" class="form-control" placeholder="Enter Nama Barang"> -->
                                <select name="category_id" class="form-select category_id" id="category_id">
                                    <option value="">--Choose Category--</option>
                                    <?php
                                    $sqlCategory = mysqli_query($connect, "SELECT * FROM category") or die (mysqli_error($connect));
                                    while($dataCategory = mysqli_fetch_array($sqlCategory)) {
                                        echo '<option value="'.$dataCategory['category_id'].'">'.$dataCategory['category_name'].'</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group mb-3">
                                <label for="store_lat" class="form-label">Latitude</label>
                                <input type="text" class="form-control" id="store_lat" name="store_lat">               
                            </div>
                            <div class="form-group mb-3">
                                <label for="store_lng" class="form-label">Longitude</label>
                                <input type="text" class="form-control" id="store_lng" name="store_lng">               
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="save_store" class="btn btn-primary">Save</button>
                            </div>                               
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="mt-3">
            <div class="table-responsive">
                </table>
                    <table id="example" class="table table-striped" style="width:100%">
                        <thead>
                            <tr class="text-center">
                                <th scope="col">No</th>
                                <th scope="col">Store Name</th>
                                <th scope="col">Store Address</th>
                                <th scope="col">Store Image</th>
                                <th scope="col">Latitude</th>
                                <th scope="col">Longitude</th>
                                <th style="display: none;">Longitude</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody >
                            <?php
                            include '../connect.php';
                            $no = 1;
                            $getData = mysqli_query($connect, "SELECT * FROM store");
                            if (mysqli_num_rows($getData)) {
                                // $ambildata = mysqli_query($koneksi, "select * from peminjaman");
                                while ($showData = mysqli_fetch_array($getData)) {
                            ?>
                            <tr>
                                <td><?php echo $no ?></td>
                                <td style="display: none;"><?php echo $showData['store_id']; ?></td>
                                <td><?php echo $showData['store_name']; ?></td>
                                <td><?php echo $showData['store_address']; ?></td>
                                <td><img src="../img/store/<?php echo $showData['store_image']; ?>" style="width:50%;"></td>
                                <td><?php echo $showData['store_lat']; ?></td>
                                <td><?php echo $showData['store_lng']; ?></td>
                                <td>
                                    <div>
                                        <a class="mx-2 no-decoration" href="edit_store.php" title="edit" data-bs-toggle="modal" data-bs-target="#edit_store<?php echo $showData['store_id']; ?>">
                                            <i class="fa-solid fa-pen-to-square" style="color: #0D6EFD;"></i>
                                        </a>
                                        <a class="mx-2" href='delete_store.php?store_id=<?php echo $showData["store_id"]; ?>' onclick="return confirm('Are you sure want to delete <?php echo $showData['store_name']; ?> from store?')">
                                            <i class="fa-solid fa-trash-can" style="color: red;"></i>
                                        </a>
                                    </div>
                                    <div class="modal fade" id="edit_store<?php echo $showData['store_id']; ?>" tabindex="-1" aria-Labelledby="editCategory" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <?php
                                            include '../connect.php';
                                            $store_id = $showData['store_id'];
                                            $sql = mysqli_query($connect, "SELECT * from store where store_id='$store_id'");
                                            $data = mysqli_fetch_array($sql);
                                            ?>
                                            <form action="edit_store.php" method="POST" name="formeditbarang">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-3">Edit Store</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="text" class="form-control" id="store_id" name="store_id" value="<?php echo $showData['store_id']; ?>" hidden>
                                                        <input type="text" class="form-control" id="category_id" name="category_id" value="<?php echo $showData['category_id']; ?>" hidden>
                                                        
                                                        <div class="form-group mb-4">
                                                            <label for="store_name" class="form-label">Store Name</label>
                                                            <input type="text" class="form-control" id="store_name" name="store_name" value="<?php echo $showData['store_name']; ?>" aria-describedby="">
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <label for="store_address" class="form-label">Store Address</label>
                                                            <input type="text" class="form-control" id="store_address" name="store_address" value="<?php echo $showData['store_address']; ?>" aria-describedby="">
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <label for="store_image" class="form-label">Current Store Image</label><br>
                                                            <img src="../img/store/<?php echo $showData['store_image']; ?>" style="width:20%;">
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <input type="file" class="form-control" id="store_image" name="store_image" value="<?php echo $showData['store_image']; ?>" aria-describedby="">
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <label class="mb-2">Category Name</label>
                                                            <!-- <input type="text" name="nama_barang" class="form-control" placeholder="Enter Nama Barang"> -->
                                                            <select name="category_id" class="form-select category_id" id="category_id">
                                                                <option value="<?php echo $data['category_id'];?>"><?php echo $data['store_category'];?></option>
                                                                <?php
                                                                $sqlCategory = mysqli_query($connect, "SELECT * FROM category") or die (mysqli_error($connect));
                                                                while($dataCategory = mysqli_fetch_array($sqlCategory)) {
                                                                    echo '<option value="'.$dataCategory['category_id'].'">'.$dataCategory['category_name'].'</option>';
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <label for="store_lat" class="form-label">Latitude</label>
                                                            <input type="text" class="form-control" id="store_lat" name="store_lat" value="<?php echo $showData['store_lat']; ?>" aria-describedby="">
                                                        </div>
                                                        <div class="form-group mb-4">
                                                            <label for="store_lng" class="form-label">Product Description</label>
                                                            <input type="text" class="form-control" id="store_lng" name="store_lng" value="<?php echo $showData['store_lng']; ?>" aria-describedby="">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary" name="save_edit_store">Save</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                                <?php
                                        $no++;
                                }
                            } else { }
                                    ?>
                            </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <script>
        $(document).ready(function () {
            $('#example').DataTable();
        });
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.print.min.js"></script>
</body>
</html>