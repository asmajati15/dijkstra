<?php
session_start();
include '../connect.php';

$queryCategory = mysqli_query($connect, "SELECT * FROM category");
$amountCategory = mysqli_num_rows($queryCategory);
$queryUser = mysqli_query($connect, "SELECT * FROM users");
$amountUser = mysqli_num_rows($queryUser);
$queryProduct = mysqli_query($connect, "SELECT * FROM product");
$amountProduct = mysqli_num_rows($queryProduct);
$queryStore = mysqli_query($connect, "SELECT * FROM store");
$amountStore = mysqli_num_rows($queryStore);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v6.0.0/css/pro.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css">
</head>

<style>
.kotak{
    border: solid;
}
.summary-category{
    background-color: #6096B4;
    border-radius: 10px;
}

.summary-product{
    background-color: #088395;
    border-radius: 15px;
}

.summary-user{
    background-color: #917FB3;
    border-radius: 15px;
}

.summary-store{
    background-color: #3F497F;
    border-radius: 15px;
}
.no-decoration{
    text-decoration: none;
}

</style>

<body>
    <?php require "navbar.php"; ?>
    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <i class="fa-solid fa-house"></i> Home
                </li>
            </ol>
        </nav>
        <h2>Halo <?php echo $_SESSION['user_name']; ?></h2>
        <div class="container mt-5">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12 mb-3">
                    <div class="summary-category p-3">
                        <div class="row">
                            <div class="col-6">
                                <i class="fa-solid fa-align-justify fa-7x text-black-50 mt-3  ms-3"></i>
                            </div>
                            <div class="col-6 text-white">
                                <h3 class="fs-2">Category</h3>
                                <p class="fs-4"><?php echo $amountCategory; ?> Category</p>
                                <p><a href="category.php" class="text-white no-decoration">See Detail</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mb-3">
                    <div class="summary-product p-3">
                        <div class="row">
                            <div class="col-6">
                                <i class="fa-solid fa-box fa-7x text-black-50 mt-3  ms-3"></i>
                            </div>
                            <div class="col-6 text-white">
                                <h3 class="fs-2">Product</h3>
                                <p class="fs-4"><?php echo $amountProduct; ?> Product</p>
                                <p><a href="product.php" class="text-white no-decoration">See Detail</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mb-3">
                    <div class="summary-user p-3">
                        <div class="row">
                            <div class="col-6">
                                <i class="fa-solid fa-user fa-7x text-black-50 mt-3  ms-3"></i>
                            </div>
                            <div class="col-6 text-white">
                                <h3 class="fs-2">Users</h3>
                                <p class="fs-4"><?php echo $amountUser; ?> User</p>
                                <p><a href="users.php" class="text-white no-decoration">See Detail</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mb-3">
                    <div class="summary-store p-3">
                        <div class="row">
                            <div class="col-6">
                                <i class="fa-solid fa-shop fa-7x text-black-50 mt-3 "></i>
                            </div>
                            <div class="col-6 text-white">
                                <h3 class="fs-2">Store</h3>
                                <p class="fs-4"><?php echo $amountStore; ?> Store</p>
                                <p><a href="store.php" class="text-white no-decoration">See Detail</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>