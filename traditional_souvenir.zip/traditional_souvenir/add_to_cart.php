<?php

include 'connect.php';

if(isset($_POST['order'])) {
    $user_id = $_POST['user_id'];
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_quantity = $_POST['product_quantity'];
    $purchase_date = date('Y-m-d');
    $transaction_status = 'Request';

    $query = "INSERT INTO cart (`user_id`, `product_id`, `product_name`, `product_price`, `product_quantity`, `purchase_date`, `transaction_status`) VALUES ('$user_id', '$product_id', '$product_name', '$product_price', '$product_quantity', '$purchase_date', '$transaction_status')";
    $query_run = mysqli_query($connect, $query);


    if($query_run) {
        header('Location: product_detail.php?product_id='.$product_id);
    } else {
        echo '<script> alert("Data not saved"); </script>';
    }
}
?>