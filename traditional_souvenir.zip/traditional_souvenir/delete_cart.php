<?php
session_start();

include 'connect.php';

$cart_id = $_GET['cart_id'];

$query = "DELETE FROM cart WHERE cart_id='$cart_id'";
$query_run = mysqli_query($connect, $query);

if($query_run) {
    header('Location: cart.php');
} else {
    echo '<script> alert("Data not updated"); </script>';
}

?>