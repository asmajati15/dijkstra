<?php 
session_start();

include 'connect.php';
 
// login process
if(isset($_POST['login'])) {
    $user_email = $_POST['user_email'];
    $user_password = $_POST['user_password'];
    
    $query = mysqli_query($connect, "SELECT * FROM users WHERE user_email='$user_email' AND `user_password`='$user_password'");
    $check = mysqli_num_rows($query);
    
    if($check > 0) {
        $data = mysqli_fetch_array($query);
        $_SESSION["user_id"] = $data['user_id'];
        $_SESSION["user_email"] = $data['user_email'];
        $_SESSION["user_name"] = $data['user_name'];
        $_SESSION["user_password"] = $data['user_password'];
        $_SESSION["user_access"] = $data['user_access'];
        if($_SESSION["user_access"]=='admin'){
            header('Location: admin/index.php');
        }     
    } else {
        header('Location: login-form.php');
    }
}
?>